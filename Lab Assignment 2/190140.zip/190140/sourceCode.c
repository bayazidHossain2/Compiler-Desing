#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<time.h>

#define pi   3.14159

int main(){
    int abd,def;
    abd=6788;
    float dfg,hij;
    double ijk,lmn;
    char mnp,qurst;

    return 0;
}
