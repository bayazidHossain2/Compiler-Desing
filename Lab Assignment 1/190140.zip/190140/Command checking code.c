#include  <stdio.h>
int main(){

    //Compiler Design
    ///Compiler Design
    Compiler//Design
    /*Compiler Design*/
    Compiler/*Compiler Design*/
    Compiler /*Compiler Design*/Design
    /*Compiler Design
    Compiler Design$Compiler Design. Compiler Design
    Compiler Design*/
    Compiler Design/*Compiler Design%Compiler Design
    Compiler Design*/
    Compiler Design/*Compiler Design//Compiler Design\\Compiler Design
    Compiler Design
    Compiler Design
    Compiler Design*/Compiler Design

    Compiler Design/*Compiler Design*/Compiler Design/*Compiler DesignCompiler DesignCompiler Design*/Compiler Design
    return 1000;
}



