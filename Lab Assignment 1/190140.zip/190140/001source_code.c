#include  <stdio.h>
int main(){
    //dkf
    return 1000;
}
